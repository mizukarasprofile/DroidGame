package menu;

import battle.BattleArena;
import battle.Team;
import models.Droid;
import models.Sniper;
import models.Support;
import models.Tank;
import storage.BattleRecorder;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Menu {
    private List<Droid> droids = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private List<String> lastBattleLog = new ArrayList<>();
    private final String FILE_NAME = "battle_log.txt";
    public void start() {
        while (true) {
            System.out.println("Керування дройдом - 1");
            System.out.println("Бій - 2");
            System.out.println("Робота з файлом - 3");
            System.out.println("Вихід з програми - 0");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    droidSubMenu();
                    break;
                case 2:
                    fightSubMenu();
                    break;
                case 3:
                    FileSubMenu();
                    break;
                case 0:
                    System.out.println("Завершення програми");
                    return;
            }
        }
    }

    void droidSubMenu() {
        int choice;
        while (true) {
            System.out.println("\nОпераціі з дройдами\n");
            System.out.println("Створити нового дройда - 1");
            System.out.println("Показати всіх дройдів - 2");
            System.out.println("Повернутись назд - 0 ");
            choice= scanner.nextInt();
            switch (choice){
                case 1:
                createDroid();
                case 2:
                showAllDroids();
                case 0:
                    System.out.println("Вихід");
                    return;
        }
    }
}
    void fightSubMenu() {
        int choice;
        while (true) {
            System.out.println("Режим битви");
            System.out.println("бій 1 на 1 (вибрати дроїдів, які будуть змагатися) - 1");
            System.out.println("бій команду на команду - 2");
            System.out.println("Повернення назад - 0");
            choice= scanner.nextInt();
            switch (choice) {
                case 1:
                    fightOnetoOne();
                    break;
                case 2:
                    fightTeamToTeam();
                    break;
                case 0:
                    System.out.println("Повернення назад");
                    return;
            }
        }
    }
    void FileSubMenu(){
        int choice;
        while(true) {
            System.out.println("Робота з файлами");
            System.out.println("Записати останній бій у файл - 1");
            System.out.println("Відтворити бій з файлу - 2");
            System.out.println("Повернутись назад - 0");
            choice= scanner.nextInt();
            switch(choice) {
                case 1:
                    saveFight();
                    break;
                case 2:
                    replayFight();
                    break;
                case 0:
                    System.out.println("Повернення назад");
                    return;
            }
                }


        }
    void createDroid(){
    System.out.println("Оберіть тип дроіда");
    System.out.println("Support(Медик) - 1");
    System.out.println("Танк(Броньований) - 2");
    System.out.println("Sniper(Крит урон)");
    int type=scanner.nextInt();
    scanner.nextLine();
    System.out.println("Введіть імя дройда");
    String name=scanner.nextLine();
    if(name.isEmpty()){
        name="Droid" + (droids.size()+1);
    }
    Droid created=null;
switch (type){
    case 1:
        created=new Support(name,90,15,90,25);
        break;case 2:
        created = new Tank(name, 140, 20, 140, 8);
        break;
    case 3:
        created = new Sniper(name, 80, 30, 80, 0.35);
        break;
    default:
        System.out.println("Невідомий тип");
        return;
}
droids.add(created);
System.out.println("Дроіда" + created.getName() + "успішно створено");
}
void showAllDroids(){
        if(droids.isEmpty()){
            System.out.println("Список порожній,спочатку створіть дройда");
            return;
        }
        System.out.println("Список усіх дройдів");
        for(int i=0;i< droids.size();i++){
            Droid d=droids.get(i);
            System.out.println((i + 1) + ". " + d.getName() + " [HP: " + d.getMaxHealth() + ", DMG: " + d.getDamage() + "]");
        }
}
void fightOnetoOne(){
    if (droids.size() < 2) {
        System.out.println("Потрібно мінімум 2 дроїди для поєдинку!");
        return;
    }
    showAllDroids();
    System.out.print("Введіть порядковий номер 1-го бійця: ");
    int idx1 = scanner.nextInt() - 1;
    System.out.print("Введіть порядковий номер 2-го бійця: ");
    int idx2 = scanner.nextInt() - 1;
    if (idx1 < 0 || idx1 >= droids.size() || idx2 < 0 || idx2 >= droids.size() || idx1 == idx2) {
        System.out.println(" Некоректний вибір дройдів для файту!");
        return;
    }
    Droid d1 = droids.get(idx1);
    Droid d2 = droids.get(idx2);
    d1.resetHealth();
    d2.resetHealth();

    Team team1 = new Team(d1.getName());
    team1.addDroid(d1);

    Team team2 = new Team(d2.getName());
    team2.addDroid(d2);

    BattleArena arena = new BattleArena("Арена",team1, team2);
    lastBattleLog = arena.startFight();
}
    void fightTeamToTeam() {
        if (droids.size() < 2) {
            System.out.println("Потрібно мінімум 2 дроїди для бою!");
            return;
        }
        Team team1 = new Team("Команда 1");
        Team team2 = new Team("Команда 2");
        System.out.println("\nФормуємо Команду 1:");
        fillTeam(team1);
        System.out.println("\nФормуємо Команду 2:");
        fillTeam(team2);
        if (team1.getDroids().isEmpty() || team2.getDroids().isEmpty()) {
            System.out.println("Обидві команди повинні мати хоча б одного бійця!");
            return;
        }
        for (int i = 0; i < team1.getDroids().size(); i++) {
            team1.getDroids().get(i).resetHealth();
        }
        for (int i = 0; i < team2.getDroids().size(); i++) {
            team2.getDroids().get(i).resetHealth();
        }
        BattleArena arena = new BattleArena("Командна арена",team1, team2);
        lastBattleLog = arena.startFight();
    }
    void fillTeam(Team team) {
        showAllDroids();
        System.out.print("Скільки дроїдів додати у " + team.getName() + "? ");
        int count = scanner.nextInt();

        for (int i = 0; i < count; i++) {
            System.out.print("Введіть номер дроїда #" + (i + 1) + ": ");
            int idx = scanner.nextInt() - 1;
            if (idx >= 0 && idx < droids.size()) {
                team.addDroid(droids.get(idx));
            } else {
                System.out.println("Невірний номер, пропуск.");
            }
        }
    }
    void saveFight() {
        BattleRecorder.saveToFile(FILE_NAME, lastBattleLog);
    }
    void replayFight() {
        BattleRecorder.replayFromFile(FILE_NAME);
    }
}

